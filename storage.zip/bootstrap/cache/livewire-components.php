<?php return array (
  'products-table' => 'App\\Http\\Livewire\\ProductsTable',
);