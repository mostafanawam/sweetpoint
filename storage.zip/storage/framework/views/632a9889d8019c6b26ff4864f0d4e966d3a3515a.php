
<?php $__env->startSection('nav'); ?>
<title>Sweet Point | Sign in</title>
<li class="nav-item ">
   <a class="nav-link " href="/shop/home">Home <span class="sr-only">(current)</span></a>
</li>
<li class="nav-item">
   <a class="nav-link " href="/shop/products">Products</a>
</li>
<li class="nav-item">
   <a class="nav-link" href="/shop/customize">Customize Order</a>
</li>
<!--<li class="nav-item dropdown">
   <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
   Support
   </a>
   <div class="dropdown-menu" aria-labelledby="navbarDropdown">
      <a class="dropdown-item" href="#">Delivery Information</a>
      <a class="dropdown-item" href="#">Privacy Policy</a>
      <a class="dropdown-item" href="#">Terms & Conditions</a>
   </div>-->
</li>
<li class="nav-item">
   <a class="nav-link" href="/shop/contact">Contact Us</a>
</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>

<div class="container">
    <h2 class="title-sell">Sign In</h2>
    <div class="row justify-content-center" >
        <div class="col-md-4 col-md-offset-4">

            <?php if(Session::get('success')): ?>
            <div class="alert alert-success text-center">
            <?php echo e(Session::get('success')); ?>

            </div>
            <?php endif; ?>

        <?php if(Session::get('fail')): ?>
            <div class="alert alert-danger text-center">
            <?php echo e(Session::get('fail')); ?>

            </div>
        <?php endif; ?>

        <?php if(session()->has('customer')): ?>
        <div class="loggin-in text-center">
            <img src="<?php echo e(asset('images/tick.png')); ?>"  class="img-fluid" alt="">
            <h4>Your are already logged in!!</h4>
           <p>Click <a  href="/shop/logout">here</a> to logout</p> 
        </div>   
        <?php else: ?>

        <form action="/shop/login/signin" method="post"><?php echo csrf_field(); ?>
            <div class="form-group">
                <label style="color: #33383b">Email</label>
                <input type="text" class="form-control" name="email" placeholder="Enter email address" value="<?php echo e(old('email')); ?>">
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?> </span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group">
                <label style="color: #33383b">Password</label>
                <input type="password" class="form-control" name="password" placeholder="Enter password">
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <button type="submit" class="btn btn-block btn-cart">Sign In</button>
            <p class="text-center" style="color: #33383b">Not Registered?
                <a href="register" class="text-center" style="color: #cb5959">Sign Up</a>
            </p>
        </form>
        <?php endif; ?>
    </div>
    </div>
    <br>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('shop.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\pc\Desktop\laravel\Shop\resources\views/shop/login.blade.php ENDPATH**/ ?>