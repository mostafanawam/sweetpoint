




<?php $__env->startSection('content'); ?>
<style>
    img{
        width: 100%;
        height: 50px;
    }
</style>
<div class="container">
    <div class="row justify-content-center" style="margin-top:45px">
    <div class="col-md-4 col-md-offset-4">
            <h4>Edit Products</h4><hr>

<form  action="/admin/updateprod" method="post">
    <?php echo csrf_field(); ?>

    <?php if(Session::get('success')): ?>
    <div class="alert alert-success text-center">
    <?php echo e(Session::get('success')); ?>

    </div>
    <?php endif; ?>

    <?php if(Session::get('fail')): ?>
    <div class="alert alert-danger text-center">
    <?php echo e(Session::get('fail')); ?>

    </div>
    <?php endif; ?>
</div>
</div>

    <div class="row justify-content-center" >
        <div class="form-group col-lg-3">
            <label class="font-weight-bold">Name</label>
            <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <input type="text" value="<?php echo e($p->name); ?>" name="name" class="form-control">
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group col-lg-3">
            <label class="font-weight-bold">Image</label>
            <img src="<?php echo e(asset('products/'.$p->image.'')); ?>" alt="">
            <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?> </span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

<input type="hidden" name="id" value="<?php echo e($p->prod_id); ?>">

        <div class="row justify-content-center" >
            <div class="form-group col-lg-6">
                    <label class="font-weight-bold">Description</label>
                    <textarea name="description" style="width: 100%" rows="1" >
                        <?php echo e($p->description); ?>

                    </textarea>
                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                
        </div>
        <div class="row justify-content-center" >
        <div class="form-group col-lg-3">
            <label class="font-weight-bold">Price</label>
            <input type="test" class="form-control" name="price" placeholder="Enter product price" value="<?php echo e($p->price); ?>">
            <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-group col-lg-3">
            <label class="font-weight-bold">Rank</label>
            <input type="text" class="form-control" name="rank" placeholder="Enter product rank" value="<?php echo e($p->rank); ?>">
            <?php $__errorArgs = ['rank'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

        
        <div class="row justify-content-center" >
            <div class="form-group col-lg-3">
                <label class="font-weight-bold">Quantity</label>
                    <input type="number" class="form-control" name="qty" placeholder="Enter product quantity" value="<?php echo e($p->quantity); ?>">
                <?php $__errorArgs = ['qty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group col-lg-3">
                <label class="font-weight-bold">Category</label>
                <select class="custom-select" name="category">
                    <option value="" disabled selected>Choose Category</option>
                    <?php $__currentLoopData = $catlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($list->cat_id==$p->cat_id): ?>
                    <option value="<?php echo e($p->cat_id); ?>" selected><?php echo e($p->cat_name); ?> </option>
                    <?php else: ?>
                    <option value="<?php echo e($list->cat_id); ?>" ><?php echo e($list->cat_name); ?> </option>
                    <?php endif; ?>
                    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="row justify-content-center" >
            <div class="form-group col-lg-3">
                <input type="submit"  value="Update" class="btn btn-primary btn-block">
            </div> 
        </div>
</form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\pc\Desktop\laravel\Shop\resources\views/admin/view.blade.php ENDPATH**/ ?>