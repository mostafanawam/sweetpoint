

<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <meta http-equiv="X-UA-Compatible" content="ie=edge">
      <title>Sweet Point | eShop</title>
      <link rel = "icon" href = "<?php echo e(asset('images/logo.jpg')); ?>" type = "image/x-icon">

      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
      <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap">
      <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.11.2/css/all.css">
      <link rel="stylesheet" href="<?php echo e(asset('css/shop-home.css')); ?>">
      <script src="<?php echo e(asset('js/shop-home.js')); ?>"></script>
      <link rel="stylesheet" href="<?php echo e(asset('css/cake.css')); ?>">
   </head>
   <body onload="myFunction()">

      


      <div class="loader_body" id="loader" style="display:none;">
      <div id="table">
          <div class="camera">
            <div class="copy">Welcome to Sweet Point!!</div>
            <div class="dishes">
              <div class="dish"></div>
              <div class="dish"></div>
              <div class="dish"></div>
              <div class="dish"></div>
              <div class="dish"></div>
              <div class="dish"></div>
            
            </div>
            <div class="cakes">
              <div class="cake">
                <div class="cake_tower">
                  <div class="cake_1">
                    <div class="wall_1"></div>
                    <div class="wall_2"></div>
                    <div class="wall_3"></div>
                    <div class="wall_4"></div>
                    <div class="cake_2">
                      <div class="wall_1"></div>
                      <div class="wall_2"></div>
                      <div class="wall_3"></div>
                      <div class="wall_4"></div>
                      <div class="cake_3">
                        <div class="wall_1"></div>
                        <div class="wall_2"></div>
                        <div class="wall_3"></div>
                        <div class="wall_4"></div>
                        <div class="fork"></div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="cake">
                <div class="cake_tower">
                  <div class="cake_1">
                    <div class="wall_1"></div>
                    <div class="wall_2"></div>
                    <div class="wall_3"></div>
                    <div class="wall_4"></div>
                    <div class="cake_2">
                      <div class="wall_1"></div>
                      <div class="wall_2"></div>
                      <div class="wall_3"></div>
                      <div class="wall_4"></div>
                      <div class="cake_3">
                        <div class="wall_1"></div>
                        <div class="wall_2"></div>
                        <div class="wall_3"></div>
                        <div class="wall_4"></div>
                        <div class="fork"></div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="cake">
                <div class="cake_tower">
                  <div class="cake_1">
                    <div class="wall_1"></div>
                    <div class="wall_2"></div>
                    <div class="wall_3"></div>
                    <div class="wall_4"></div>
                    <div class="cake_2">
                      <div class="wall_1"></div>
                      <div class="wall_2"></div>
                      <div class="wall_3"></div>
                      <div class="wall_4"></div>
                      <div class="cake_3">
                        <div class="wall_1"></div>
                        <div class="wall_2"></div>
                        <div class="wall_3"></div>
                        <div class="wall_4"></div>
                        <div class="fork"></div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="cake">
                <div class="cake_tower">
                  <div class="cake_1">
                    <div class="wall_1"></div>
                    <div class="wall_2"></div>
                    <div class="wall_3"></div>
                    <div class="wall_4"></div>
                    <div class="cake_2">
                      <div class="wall_1"></div>
                      <div class="wall_2"></div>
                      <div class="wall_3"></div>
                      <div class="wall_4"></div>
                      <div class="cake_3">
                        <div class="wall_1"></div>
                        <div class="wall_2"></div>
                        <div class="wall_3"></div>
                        <div class="wall_4"></div>
                        <div class="fork"></div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="cake">
                <div class="cake_tower">
                  <div class="cake_1">
                    <div class="wall_1"></div>
                    <div class="wall_2"></div>
                    <div class="wall_3"></div>
                    <div class="wall_4"></div>
                    <div class="cake_2">
                      <div class="wall_1"></div>
                      <div class="wall_2"></div>
                      <div class="wall_3"></div>
                      <div class="wall_4"></div>
                      <div class="cake_3">
                        <div class="wall_1"></div>
                        <div class="wall_2"></div>
                        <div class="wall_3"></div>
                        <div class="wall_4"></div>
                        <div class="fork"></div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="cake">
                <div class="cake_tower">
                  <div class="cake_1">
                    <div class="wall_1"></div>
                    <div class="wall_2"></div>
                    <div class="wall_3"></div>
                    <div class="wall_4"></div>
                    <div class="cake_2">
                      <div class="wall_1"></div>
                      <div class="wall_2"></div>
                      <div class="wall_3"></div>
                      <div class="wall_4"></div>
                      <div class="cake_3">
                        <div class="wall_1"></div>
                        <div class="wall_2"></div>
                        <div class="wall_3"></div>
                        <div class="wall_4"></div>
                        <div class="fork"></div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
             
             
             
             
            </div>
          </div>
        </div>
            
      </div>


      <div id="myDiv" ><!-- style="display:none;"-->

      <div class="overlay"></div>
      <div class="utility-nav d-none d-md-block " style="background-color:rgb(247, 243, 243)">
         <div class="container">
           <div class="row">
             <div class="col-12 col-md-6">
               <p class="small"> Cash on delivery - <i class="fab fa-whatsapp"></i> 0096181602936
               </p>
             </div>
         
             <div class="col-12 col-md-6 text-right">
               <p class="">EN
              </p>
             </div>
           </div>
         </div>
         </div>
      <nav class="navbar navbar-expand-md navbar-light bg-light main-menu" style="box-shadow:none">
         <div class="container">
            <button type="button" id="sidebarCollapse" class="btn btn-link d-block d-md-none">
            <i class="fas fa-bars text-dark icon-single"></i>
            </button>
            <a class="navbar-brand text-center" href="/shop">
               <img src="<?php echo e(asset('images/logo.jpg')); ?>" alt="" 
                 class="img-fluid rounded-circle">
            </a>
            <ul class="navbar-nav ml-auto d-block d-md-none">
               <li class="nav-item">
                  <a class="btn btn-link" href="#"><i class="fas fa-shopping-cart icon-single"></i><span class="badge badge-danger">3</span>
                  </a>
               </li>
            </ul>
            <div class="collapse navbar-collapse">
               <form class="form-inline my-2 my-lg-0 mx-auto">
                  <input class="form-control" type="search" placeholder="Search for products..." aria-label="Search">
                  <button class="btn search-btn my-2 my-sm-0"  type="submit"><i class="fas fa-search"></i></button>
               </form>
               <ul class="navbar-nav">
                  <li class="nav-item">
                     <a class="btn btn-link" href="#"><i class="fas fa-shopping-cart icon-single"></i> 
                     <span class="badge badge-danger">2</span></a>
                  </li>
                  <li class="nav-item ml-md-3">
                     <a class="btn btn-login"  href="#"><i class="fas fa-user-circle mr-1"></i> Log In / Register</a>
                  </li>
               </ul>
            </div>
         </div>
      </nav>
      <nav class="navbar navbar-expand-md navbar-light bg-light sub-menu">
         <div class="container">
            <div class="collapse navbar-collapse" id="navbar">
               <ul class="nav navbar-nav navbar-nav mx-auto">
                  <li class="nav-item active">
                     <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link" href="#">Products</a>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link" href="#">Customize Order</a>
                  </li>
                  <li class="nav-item dropdown">
                     <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                     Support
                     </a>
                     <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <a class="dropdown-item" href="#">Delivery Information</a>
                        <a class="dropdown-item" href="#">Privacy Policy</a>
                        <a class="dropdown-item" href="#">Terms & Conditions</a>
                     </div>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link" href="#">Contact</a>
                  </li>
               </ul>
            </div>
         </div>
      </nav>
      <div class="search-bar d-block d-md-none" style="background-color: wheat;">
         <div class="container">
            <div class="row">
               <div class="col-12">
                  <form class="form-inline mb-3 mx-auto">
                     <input class="form-control" type="search" placeholder="Search for products..." aria-label="Search">
                     <button class="btn search-btn" type="submit"><i class="fas fa-search"></i></button>
                  </form>
               </div>
            </div>
         </div>
      </div>
      <!-- Sidebar -->
      <nav id="sidebar">
         <div class="sidebar-header">
            <div class="container">
               <div class="row align-items-center">
                  <div class="col-10 pl-0">
                     <a class="btn btn-login" href="#"><i class="fas fa-user-circle mr-1"></i>Log In / Register</a>
                  </div>
                  <div class="col-2 text-left">
                     <button type="button" id="sidebarCollapseX" class="btn btn-link">
                     <i class="fas fa-times icon-single text-dark"></i>
                     </button>
                  </div>
               </div>
            </div>
         </div>
         <ul class="list-unstyled components links">
            <li class="active">
               <a href="#"><i class="fas fa-home mr-3"></i> Home</a>
            </li>
            <li>
               <a href="#"><i class="fas fa-carousel mr-3"></i> Products</a>
            </li>
            <li>
               <a href="#"><i class="fas fa-book-open mr-3"></i> Schools</a>
            </li>
            <li>
               <a href="#"><i class="bx bx-crown mr-3"></i> Publishers</a>
            </li>
            <li>
               <a href="#pageSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">
                  <i class="fas fa-help-circle mr-3"></i>
               Support</a>
               <ul class="collapse list-unstyled" id="pageSubmenu">
                  <li>
                     <a href="#">Delivery Information</a>
                  </li>
                  <li>
                     <a href="#">Privacy Policy</a>
                  </li>
                  <li>
                     <a href="#">Terms & Conditions</a>
                  </li>
               </ul>
            </li>
            <li>
               <a href="#"><i class="fas fa-phone mr-3"></i> Contact</a>
            </li>
         </ul>
         <h6 class="text-uppercase mb-1">Categories</h6>
         <ul class="list-unstyled components mb-3">
            <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
               <a href="/<?php echo e($cat->cat_name); ?>"><?php echo e($cat->cat_name); ?></a>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
         </ul>
      </nav>
      


<br>
<div id="demo" class="carousel slide" data-ride="carousel">

  <!-- Indicators -->
  <ul class="carousel-indicators">
    <li data-target="#demo" data-slide-to="0" class="active"></li>
    <li data-target="#demo" data-slide-to="1"></li>
    <li data-target="#demo" data-slide-to="2"></li>
  </ul>
  
  <!-- The slideshow -->
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="<?php echo e(asset('carousel/1462194.webp')); ?>" alt="Los Angeles" width="1100" height="500">
    </div>
    <div class="carousel-item">
      <img src="<?php echo e(asset('carousel/carosel2.jpg')); ?>" alt="Chicago" width="1100" height="500">
    </div>
    <div class="carousel-item">
      <img src="<?php echo e(asset('carousel/car.jpg')); ?>" alt="New York" width="1100" height="500">
    </div>
  </div>
  
  <!-- Left and right controls -->
  <a class="carousel-control-prev" href="#demo" data-slide="prev">
    <span class="carousel-control-prev-icon"></span>
  </a>
  <a class="carousel-control-next" href="#demo" data-slide="next">
    <span class="carousel-control-next-icon"></span>
  </a>
</div>
  
<style>

</style>

<div class="container">
   <h2 class="title-sell">Best Sellers</h2>

   <div class="container mt-5 mb-5">
      <div class="row g-2">
         <?php $__currentLoopData = $best_sellers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $best): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="form-group col-md-3 d-flex justify-content-center">
              <div class="card p-2">
                  <div class="text-center"> <img src="<?php echo e(asset('products/'.$best->image.'')); ?>" class="img-fluid rounded"/> </div>
                  <div class="content">
                      <div class="d-flex justify-content-between align-items-center"> <span class="category"><?php echo e($best->name); ?></span> <span class="price"><?php echo e($best->price); ?> L.L</span> </div>
                      <p><?php echo e($best->description); ?></p>
                      <div class="buttons d-flex justify-content-center">
                        <button class="btn btn-outline">Add to cart</button> </div>
                  </div>
              </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
  </div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/ekko-lightbox/5.3.0/ekko-lightbox.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ekko-lightbox/5.3.0/ekko-lightbox.css">
<link rel="stylesheet" href="">
<script src="<?php echo e(asset('js/ourwork.js')); ?>"></script>
<link rel="stylesheet" href="<?php echo e(asset('css/ourwork.css')); ?>">

  <h2 class="title-sell">Our Work in Review</h2>
  <div class="container">
   <div class="row row1 rowtable">

      <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php
      $row=explode("/",$image);
      //echo $row[2];
      ?>
      <a href="<?php echo e(asset('storage/gallery/'.$row[2].'')); ?>" data-toggle="lightbox" data-gallery="gallery" class="column effect11">
         <img src="<?php echo e(asset('storage/gallery/'.$row[2].'')); ?>" class="rounded img1">
       </a>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   </div>
 </div>




  <!--<h2 class="title-sell">Build Your Cake</h2>
  <div class="container mt-5 mb-5">
  
   <div class="text-center">
      <a href="" class="more-product">See more...</a>
   </div>
</div>-->

  
</div><!-- end container-->



<footer class="footer-distributed">

			<div class="footer-left">

				<h3>Sweet<span>Point</span></h3>

				
			</div>

			<div class="footer-center">

				<div>
					<i class="fas fa-map-marker"></i>
					<p><span>444 S. Cedros Ave</span> Solana Beach, California</p>
				</div>

				<div>
					<i class="fas fa-phone"></i>
					<p>00961 81936963</p>
				</div>

				<div>
					<i class="fa fa-envelope"></i>
					<p><a href="mailto:support@company.com">support@company.com</a></p>
				</div>

			</div>

			<div class="footer-right">

				<p class="footer-company-about">
					<span>About the company</span>
					Lorem ipsum dolor sit amet, consectateur adispicing elit. Fusce euismod convallis velit, eu auctor lacus vehicula sit amet.
				</p>

				<div class="footer-icons">

					<a href="#"><i class="fab fa-facebook"></i></a>
					<a href="#"><i class="fab fa-twitter"></i></a>
					<a href="#"><i class="fab fa-linkedin"></i></a>
					<a href="#"><i class="fab fa-github"></i></a>

				</div>

			</div>
         <p class="text-center txt-link" style="font-size: 0.8rem;">Developed by <a href="https://mostafanawam.github.io/" class="name-link" target="_blank"> Mostafa Nawam </a>© <?php echo e(now()->year); ?></p>
		</footer>

   </div><!-- end myDiv -->
</body>
</html><?php /**PATH C:\Users\pc\Desktop\laravel\Shop\resources\views/shop.blade.php ENDPATH**/ ?>