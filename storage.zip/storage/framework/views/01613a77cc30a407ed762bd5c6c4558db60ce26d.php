


<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row justify-content-center" style="margin-top:45px">
        <div class="col-md-4 col-md-offset-4">
            <h4>Order Details</h4><hr>
        </div>
    
        
        <div class="table-responsive">
            <p>Customer name:</p>
            <p>Address:</p>
            <table class="table tabled-bordered table-striped text-center">
                <thead>
                    <tr>
                        <th>Product</th>
                        <th>Quantity</th>
                        <th>Unit Price</th>
                        <th>Total Price</th>
                    </tr>
                </thead>
                
                <tbody>
                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th><?php echo e($order->name); ?></th>
                        <th><?php echo e($order->qty); ?></th>
                        <th><?php echo e($order->price); ?></th>
                        <th><?php echo e($order->qty*$order->price); ?></th>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tfoot>
                        <tr>
                            <th>Total</th>
                            <th><?php echo e($qty); ?></th>
                            <th></th>
                            <th ><?php echo e($price); ?> L.L</th>
                        </tr>
                </tbody>
                
                </tfoot>
            </table>
        </div>
        
            <div class="col-md-4 col-md-offset-4"><br>
                <form action="" method="post"><?php echo csrf_field(); ?>
                    <button class="btn btn-primary btn-block" type="submit">Print</button>
                </form>
            </div>
        
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\pc\Desktop\laravel\Shop\resources\views/admin/orderdetails.blade.php ENDPATH**/ ?>