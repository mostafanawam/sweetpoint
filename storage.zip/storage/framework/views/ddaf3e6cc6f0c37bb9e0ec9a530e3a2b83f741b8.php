


<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center" style="margin-top:45px">
        <div class="col-md-4 col-md-offset-4">
        <h4>Orders List</h4><hr>
        </div>
        <div class="table-responsive">
            <table class="table tabled-bordered table-striped text-center">
                <tr>
                    <th>OrderID</th>
                    <th>Customer</th>
                    <th>Total</th>
                    <th>Pickup</th>
                    <th>Date</th>
                    <th>Note</th>
                    <th>Action</th>
                </tr>
                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th><?php echo e($order->orderid); ?></th>
                    <th><?php echo e($order->firstname); ?> <?php echo e($order->lastname); ?></th>
                    <th><?php echo e($order->total); ?> L.L</th>
                    <th><?php echo e($order->pickup); ?></th>
                    <th><?php echo e($order->date); ?></th>
                    <th><?php echo e($order->note); ?></th>
                    <th>
                        <a href="/admin/order/<?php echo e($order->orderid); ?>" class="btn btn-primary">details</a>
                    </th>
                   
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
        
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\pc\Desktop\laravel\Shop\resources\views/admin/order.blade.php ENDPATH**/ ?>