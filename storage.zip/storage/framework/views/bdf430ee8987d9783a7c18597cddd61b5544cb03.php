


<?php $__env->startSection('content'); ?>
<style>
    img{
        width: 100%;
        height: 50px;
    }
</style>

<script type="text/javascript">
    function confirm1(id) {
        var del=confirm("Do you want to delete user?");//ask the user if want to delete
            if(del){//if yes => delete item
                let stateObj = { id: "100" };
                window.history.replaceState(stateObj,
                    "delete", "/admin/list/delete/"+id);
            }
    }
    </script>
<div class="container">
    <form action="addcategory" method="post">
        <div class="row justify-content-center" style="margin-top:45px">
            <div class="col-md-4 col-md-offset-4">
                <h4 class="">Products List</h4><hr>

                <?php if(Session::get('success')): ?>
                <div class="alert alert-success text-center">
                <?php echo e(Session::get('success')); ?>

                </div>
                <?php endif; ?>
            
                <?php if(Session::get('fail')): ?>
                <div class="alert alert-danger text-center">
                <?php echo e(Session::get('fail')); ?>

                </div>
                <?php endif; ?>
            </div>

        <div class="table-responsive">
            <table class="table tabled-bordered table-striped text-center">
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Description</th>
                    <th>Price</th>
                    <th>Category</th>
                    <th>Quantity</th>
                    <th>Rank</th>
                    <th>Image</th>
                    <th>Action</th>
                </tr>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th><?php echo e($prod->prod_id); ?></th>
                    <th><?php echo e($prod->name); ?></th>
                    <th><?php echo e($prod->description); ?></th>
                    <th><?php echo e($prod->price); ?></th>
                    <th><?php echo e($prod->cat_name); ?></th>
                    <th><?php echo e($prod->quantity); ?></th>
                    <th><?php echo e($prod->rank); ?></th>
                    <th> <img src="<?php echo e(asset('products/'.$prod->image.'')); ?>" alt="product"> </th>
                    <th>
                        <a href="list/view/<?php echo e($prod->prod_id); ?>" class="btn btn-primary">View</a>
                        

                        <a  href="" onclick="confirm1('<?php echo e($prod->prod_id); ?>')" class="btn btn-danger">Delete</a>

                    </th>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
        
    </div>
    </form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\pc\Desktop\laravel\Shop\resources\views/admin/list.blade.php ENDPATH**/ ?>