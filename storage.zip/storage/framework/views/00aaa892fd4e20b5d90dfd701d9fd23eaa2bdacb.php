<div>
  Product table here
</div>
<?php /**PATH C:\Users\pc\Desktop\laravel\Shop\resources\views/livewire/products-table.blade.php ENDPATH**/ ?>