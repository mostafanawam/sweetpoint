



<?php $__env->startSection('content'); ?>
<div class="container">
    <form action="addcategory" method="post">
        <?php echo csrf_field(); ?>
    <div class="row justify-content-center" style="margin-top:45px">
        <div class="col-md-6 col-md-offset-4">
            <h4>Category List</h4><hr>

                <?php if(Session::get('success')): ?>
                    <div class="alert alert-success text-center">
                        <?php echo e(Session::get('success')); ?>

                    </div>
                <?php endif; ?>

                <?php if(Session::get('fail')): ?>
                    <div class="alert alert-danger text-center">
                        <?php echo e(Session::get('fail')); ?>

                    </div>
                <?php endif; ?>

                <table class="table table-bordered  table-striped text-center">
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Action</th>
                    </tr>
                    <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th><?php echo e($cat->cat_id); ?></th>
                            <th><?php echo e($cat->cat_name); ?></th>
                            <th> 
                                <a href="deletecat/<?php echo e($cat->cat_id); ?>" class="btn btn-danger">Delete</a>
                                <a href="viewcat/<?php echo e($cat->cat_id); ?>" class="btn btn-primary">View</a>
                            </th>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
    </div>

    <div class="row justify-content-center" style="margin-top:45px">
        <div class="col-md-4 col-md-offset-4">
            <h4>Insert Category</h4><hr>

            <div class="form-group">
                <label class="font-weight-bold">Name</label>
                <input type="text" class="form-control" name="name" placeholder="Enter category name" value="<?php echo e(old('name')); ?>">
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?> </span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            
            <button type="submit" class="btn btn-block btn-primary">Insert</button>

            
        </div>
    </div>
</form>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\pc\Desktop\laravel\Shop\resources\views/admin/categories.blade.php ENDPATH**/ ?>