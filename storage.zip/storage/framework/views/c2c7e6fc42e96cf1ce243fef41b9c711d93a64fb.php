


<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/gallery.css')); ?>">

<div class="container">
    <form method='post' enctype="multipart/form-data" action="upload">
        <?php echo csrf_field(); ?>

        <?php if(Session::get('success')): ?>
        <div class="alert alert-success text-center">
            <?php echo e(Session::get('success')); ?>

        </div>
        <?php endif; ?>

        <?php if(Session::get('fail')): ?>
        <div class="alert alert-danger text-center">
            <?php echo e(Session::get('fail')); ?>

        </div>
        <?php endif; ?>
        
        <div class="rowtable">
            <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
            $row=explode("/",$image);
            //echo $row[2];
            ?>
            <div class="column">
                <img class="img"  src="<?php echo e(asset('storage/gallery/'.$row[2].'')); ?>" onclick='display(this.src)'>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
<br>
        <div class="row">

            <div class="form-group col-lg-4">
                    <input class="custom-file" type=file name='image'>
                    <span class="text-danger"><?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
            </div>
            <div class=" form-group col-lg-2">
                <input type='submit'  value='Upload'  class="btn btn-primary">
            </div>

            </form>

            <div class=" form-group col-lg-2">
                <form action="/admin/gallery/delete" method="POST">
                        <?php echo csrf_field(); ?>
                    <input type='submit'  value='Delete'  class=" btn btn-danger" id='btnDelete' disabled>
                    <input type='hidden' name ='temp_photo' id ='txtPhotoName'>
                </form>
            </div>
        </div>
        <br>
        <div class="row justify-content-center">
            <img src="" id="photo" width='300' >
        </div>

    <script>

            function display(src){//src: source of the clicked image
                //display the image with width = 300px
                document.getElementById("photo").src = src;
                //store the name of image in order send it to the Server
                //when the delete button is clicked
                document.getElementById("txtPhotoName").value = src;
                //activate the delete button
                document.getElementById("btnDelete").disabled = false;
            }

    </script>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\pc\Desktop\laravel\Shop\resources\views/admin/gallery.blade.php ENDPATH**/ ?>