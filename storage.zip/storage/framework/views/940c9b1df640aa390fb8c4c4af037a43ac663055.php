
<?php $__env->startSection('nav'); ?>
<title>Sweet Point | Sign up</title>
<li class="nav-item ">
   <a class="nav-link " href="/shop/home">Home <span class="sr-only">(current)</span></a>
</li>
<li class="nav-item">
   <a class="nav-link " href="/shop/products">Products</a>
</li>
<li class="nav-item">
   <a class="nav-link" href="/shop/customize">Customize Order</a>
</li>
<!--<li class="nav-item dropdown">
   <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
   Support
   </a>
   <div class="dropdown-menu" aria-labelledby="navbarDropdown">
      <a class="dropdown-item" href="#">Delivery Information</a>
      <a class="dropdown-item" href="#">Privacy Policy</a>
      <a class="dropdown-item" href="#">Terms & Conditions</a>
   </div>-->
</li>
<li class="nav-item">
   <a class="nav-link" href="/shop/contact">Contact Us</a>
</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>

<div class="container">
    <form action="register/signup" method="POST"><?php echo csrf_field(); ?>
    <h2 class="title-sell">Sign Up</h2>
    
    <div class="row justify-content-center" >
        <div class="form-group col-md-6">
        
        <?php if(Session::get('fail')): ?>
            <div class="alert alert-danger text-center">
            <?php echo e(Session::get('fail')); ?>

            </div>
        <?php endif; ?>
        </div>
    </div>
            

    <div class="row justify-content-center" >
        <div class="form-group col-md-3">
                <label style="color: #33383b">Firstname</label>
                <input type="text" class="form-control" name="firstname" placeholder="Enter firstname" value="<?php echo e(old('firstname')); ?>">
                <?php $__errorArgs = ['firstname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?> </span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-group col-md-3">
            <label style="color: #33383b">Lastname</label>
            <input type="text" class="form-control" name="lastname" placeholder="Enter lastname" value="<?php echo e(old('lastname')); ?>">
            <?php $__errorArgs = ['lastname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?> </span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
       
    </div>
    <div class="row justify-content-center" >
        <div class="form-group col-md-3">
            <label style="color: #33383b">Email</label>
            <input type="text" class="form-control" name="email" placeholder="Enter email address" value="<?php echo e(old('email')); ?>">
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?> </span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group col-md-3">
            <label style="color: #33383b">Password</label>
            <input type="password" class="form-control" name="password" placeholder="Enter password">
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="row justify-content-center" >
        <div class="form-group col-md-3">
            <label style="color: #33383b">Phone</label>
            <input type="tel" class="form-control" name="phone" placeholder="Enter phone number" value="<?php echo e(old('phone')); ?>">
            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?> </span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
        <div class="form-group col-md-3">
            <label style="color: #33383b">City</label>
            <input type="text" class="form-control" name="city" placeholder="Enter city" value="<?php echo e(old('city')); ?>">
            <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        
    </div>

    <div class="row justify-content-center" >
        <div class="form-group col-md-3">
            <label style="color: #33383b">Street</label>
            <input type="text" class="form-control" name="street" placeholder="Enter street" value="<?php echo e(old('street')); ?>">
            <?php $__errorArgs = ['street'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group col-md-3">
            <label style="color: #33383b">Building</label>
            <input type="text" class="form-control" name="building" placeholder="Enter building name and floor number"
             value="<?php echo e(old('building')); ?>">
            <?php $__errorArgs = ['building'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>
    <div class="row justify-content-center">
            <div class="col-lg-3">
                <button type="submit" class="btn btn-block btn-cart">Sign Up</button>
                <p class="text-center" style="color: #33383b">Already Registered?
                    <a href="login" class="text-center" style="color: #cb5959">Sign In</a>
                </p>
            </div>
    </div>
        
        </form>
    </div>
    </div>
    <br>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('shop.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\pc\Desktop\laravel\Shop\resources\views/shop/register.blade.php ENDPATH**/ ?>