




<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center" style="margin-top:45px">
    <div class="col-md-4 col-md-offset-4">
            <h4>Edit Categories</h4><hr>

    
    <form  action="/admin/updatecat" method="post">
    <?php echo csrf_field(); ?>

    <?php if(Session::get('success')): ?>
    <div class="alert alert-success text-center">
    <?php echo e(Session::get('success')); ?>

    </div>
    <?php endif; ?>

    <?php if(Session::get('fail')): ?>
    <div class="alert alert-danger text-center">
    <?php echo e(Session::get('fail')); ?>

    </div>
    <?php endif; ?>


    <div class="form-group">
        <label class="font-weight-bold">Name</label>
        <input type="text" value="<?php echo e($cat->cat_name); ?>" name="name" class="form-control">
        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="form-group">
        <input type="submit"  value="Update" class="btn btn-primary btn-block">
        
    </div>

</form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\pc\Desktop\laravel\Shop\resources\views/admin/viewcat.blade.php ENDPATH**/ ?>