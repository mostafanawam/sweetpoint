


<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row justify-content-center" style="margin-top:45px">
        <div class="col-md-4 col-md-offset-4">
        <h4>Change Password</h4><hr>

<form  action="/admin/change" method="post">
    <?php echo csrf_field(); ?>

        <?php if(Session::get('success')): ?>
        <div class="alert alert-success text-center">
        <?php echo e(Session::get('success')); ?>

        </div>
        <?php endif; ?>

        <?php if(Session::get('fail')): ?>
        <div class="alert alert-danger text-center">
        <?php echo e(Session::get('fail')); ?>

        </div>
        <?php endif; ?>


        <div class="form-group">
            <label class="font-weight-bold">Current Password</label>
            <input type="password" value="<?php echo e(old('CurrentPassword')); ?>" name="CurrentPassword" placeholder="Current Password" class="form-control">
            <?php $__errorArgs = ['CurrentPassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>


        <div class="form-group">
            <label class="font-weight-bold">New Password</label>
            <input type="password" name="NewPassword" value="<?php echo e(old('NewPassword')); ?>" placeholder="New Password" class="form-control">
            <?php $__errorArgs = ['NewPassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-group">
            <label class="font-weight-bold">Confirm Password</label>
            <input type="password" name="confirm_password" value="<?php echo e(old('confirm_password')); ?>" placeholder="Re-enter Password" class="form-control">
            <?php $__errorArgs = ['confirm_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-group">
            <input type="submit"  value="Change Password" class="btn btn-primary btn-block">
            <p class="text-center"><a href="forget"> Forgetten password?</a></p>
        </div>
    
    

</form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\pc\Desktop\laravel\Shop\resources\views/admin/changepass.blade.php ENDPATH**/ ?>