


<?php $__env->startSection('nav'); ?>
<title>Sweet Point | Products</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<li class="nav-item ">
   <a class="nav-link " href="/shop/home">Home <span class="sr-only">(current)</span></a>
</li>
<li class="nav-item">
   <a class="nav-link active" href="/shop/products">Products</a>
</li>
<li class="nav-item">
   <a class="nav-link" href="/shop/customize">Customize Order</a>
</li>
<!--<li class="nav-item dropdown">
   <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
   Support
   </a>
   <div class="dropdown-menu" aria-labelledby="navbarDropdown">
      <a class="dropdown-item" href="#">Delivery Information</a>
      <a class="dropdown-item" href="#">Privacy Policy</a>
      <a class="dropdown-item" href="#">Terms & Conditions</a>
   </div>-->
<li class="nav-item">
   <a class="nav-link" href="/shop/contact">Contact Us</a>
</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>



   <div class="container">

      
   <div class="row">
     
   <div class="col-lg-12">
   <div class="heading-title text-center">
      <h2 class="title-sell">Special Menu</h2>
   </div></div></div>

   <div class="row">
      <div class="col-lg-12">
         <div class="special-menu text-center">
            <div class="button-group filter-button-group">
               <button class="active btn-cat" data-filter="*">All</button>
               <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <button data-filter=".<?php echo e($cat->cat_id); ?>" class="btn-cat"><?php echo e($cat->cat_name); ?></button>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div></div></div></div>
<br>
<form action="" method="POST">
   <?php echo csrf_field(); ?>

            <div class='row special-list'>
               <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  
                  <div class="form-group col-lg-3 col-md-3 col-sm-3 col-xs-3 special-grid <?php echo e($prod->cat_id); ?>">
                    
                     <div class="card p-2">
                           <div class="text-center"> 
                              <img src="<?php echo e(asset('products/'.$prod->image.'')); ?>" class="img-fluid rounded"/> 
                           </div>
                           <div class="content">
                              <div class="d-flex justify-content-between align-items-center"> 
                                 <span class="category"><?php echo e($prod->name); ?></span> 
                                 <span class="price"><?php echo e($prod->price); ?> L.L</span>
                              </div>
                              <p><?php echo e($prod->description); ?></p>
                        <div class="buttons d-flex justify-content-center">
<button type="button" class="btn btn-outline add-to-cart"
 id="btn<?php echo e($prod->prod_id); ?>" onclick="AddToCart('<?php echo e($prod->prod_id); ?>')" value="">Add to Cart</button>
                        </div>
                           </div>
                     </div>
                  </div>
            
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        
             
<link rel="stylesheet" href="<?php echo e(asset('css/menu.css')); ?>">
<script src="<?php echo e(asset('js/menu-filter.js')); ?>">
</script>
   </div>
<!-- End Menu -->

</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('shop.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\pc\Desktop\laravel\Shop\resources\views/shop/products.blade.php ENDPATH**/ ?>