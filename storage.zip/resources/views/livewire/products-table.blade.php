<div>
  Product table here
</div>
